"use server"

import { cookies } from "next/headers";
import { redirect } from "next/navigation";

export const createPayment = async () => {
    const cookieStore = await cookies();
    const token = cookieStore.get("accessToken")?.value || null;
    const res = await fetch(`${process.env.BACKEND_API_URL}/api/payments/create`, {
        method: "POST",
        headers: {
            Authorization: `Bearer ${token}`,
        },
    })
    const result = await res.json();

    if(result.success && result.data?.paymentUrl) {
        redirect(result.data.paymentUrl);
    }

    return result;
}