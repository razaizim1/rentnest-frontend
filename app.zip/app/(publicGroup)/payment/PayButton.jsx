"use client"

import { useActionState } from "react"
import { createPayment } from "../_actions/createPayment"
import { useEffect } from "react"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"

export function PayButton() {
    const [state, action, pending] = useActionState(createPayment, null)

    useEffect(() => {
        if (!state) return;

        if(!state.success){
            toast.error(state.message || "Payment failed");
        }
    },[state])

    return (
        <form action={action}>
            <Button type="submit" disabled={pending}  className="flex-1">
                {pending ? "Processing..." : "Pay Now"}
            </Button>
        </form>
    )
}